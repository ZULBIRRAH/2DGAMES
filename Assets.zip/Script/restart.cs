using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class restart : MonoBehaviour
{
    public int restrt;

    public void Restarting()
    {
        SceneManager.LoadScene(restrt);
    }
    
}
