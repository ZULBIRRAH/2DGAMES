using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; 


public class MusicControl : MonoBehaviour
{
   public static MusicControl instance = null;
   public AudioSource musicSource;
   

   private void Awake()
   {


    if (instance == null)
    {
        instance = this;
      
    }
    else if(instance != this)
    {
        Destroy(gameObject);
    }
    
        DontDestroyOnLoad (gameObject);

   }
       public void StopMusic(AudioClip clip)
    {
        if ( SceneManager.GetActiveScene().name == "3-Peter1st" )
       {
         musicSource.volume = 0;
       }
        
    }
   
}
