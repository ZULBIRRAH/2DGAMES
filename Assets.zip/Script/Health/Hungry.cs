using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hungry : MonoBehaviour
{
   [SerializeField] private float startingHunger;
   public float currentHunger {get; private set;}
   private Animator anim;
   private UIManager uiManager; 
   public GameObject gameOverScreen;
   
   private void Awake()
   {
    currentHunger = startingHunger; // not 0 or full, as player need to find healthy food
    anim = GetComponent<Animator>(); // player affected
    
   }

   public void TakeDamage(float _damage) // for the hungry deduct
   {
    currentHunger = Mathf.Clamp(currentHunger - _damage, 0, startingHunger); // currenthunger - damage, min 0, max startinghunger
    
    if(currentHunger > 0) // if player collide junk, player hurt, hungry decrease
    {
        anim.SetTrigger("hurt"); // animation hurting
    }
    
    if (currentHunger == 0) // if player die
    {
        GetComponent<playerController>().enabled = false; // player cant move
        gameOverScreen.SetActive(true); // gameover displayed
    }
   }

   public void Food(float health) // eat healthy food
   {
        currentHunger+=2; // hunger increase by 2
   }

}
