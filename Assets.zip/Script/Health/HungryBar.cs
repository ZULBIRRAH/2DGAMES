using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HungryBar : MonoBehaviour
{
    [SerializeField] private Hungry playerHunger;
    [SerializeField] private Image totalHunger;
    [SerializeField] private Image currentHungerBar;

    private void Start()
    {
        totalHunger.fillAmount = playerHunger.currentHunger / 10;

    }

    private void Update()
    {
        currentHungerBar.fillAmount = playerHunger.currentHunger / 10;
    }
}
