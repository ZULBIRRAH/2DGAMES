using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Food : MonoBehaviour
{
    private float health;
    private float increase;
    private TextMeshProUGUI coinsText;
    private UIManager uiManager; 
    private Collect collect;

    [SerializeField] private AudioSource infoSound;
     
    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            collision.GetComponent<Hungry>().Food(health); 
            collision.GetComponent<Collect>().AddFood(increase);
        }
        if (collision.tag == "Collectible")
        {
            infoSound.Play();
            Destroy(collision.gameObject);
        }
    }
}
