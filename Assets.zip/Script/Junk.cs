using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Junk : MonoBehaviour
{
    [SerializeField] private float damage;
    private UIManager uiManager; 
     
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player") // player collide
        {
            collision.GetComponent<Hungry>().TakeDamage(damage); // effect player hunger
        }
        if (collision.tag == "Junk") // collide with junk
        {
            Destroy(collision.gameObject); // destroy junk
        }
    }
}
