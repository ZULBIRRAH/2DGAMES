using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class nextlevel : MonoBehaviour
{
    public static nextlevel instance;
    
    [SerializeField]private GameObject display;
    [SerializeField] private AudioSource nextlevelSound;
    public int nextScene;
    private int pass;
 
    public void Awake()
    {
        display.SetActive(false);
        instance = this;
    }
    
    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            nextlevelSound.Play();
            collision.GetComponent<Collect>().level(pass);
        }
        if (collision.tag == "nextLevel")
            {
                SceneManager.LoadScene(nextScene);
            }
    }
     public void next()
    {
        nextlevelSound.Play();
        display.SetActive(true);
    }
}

