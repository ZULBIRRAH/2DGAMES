using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class TextSlider : MonoBehaviour
{
    [SerializeField] Slider VolSlider;

    private Slider slider;

    void Start()
    {

        if(!PlayerPrefs.HasKey("MusicControl"))  // if first time play, the volume set to 100
        {
            PlayerPrefs.SetFloat("MusicControl",1);
            Load();
        }
        else
        {
            Load(); // if user already saved the volume, it will load that value
        }
    }

    public void ChangeVolume()
    {
        AudioListener.volume = VolSlider.value; //to change the volume value
        Save(); // will be saved if the player change the volume
    }


    private void Load()
    {
        VolSlider.value = PlayerPrefs.GetFloat("MusicControl");

    }

    private void Save()
    {
        PlayerPrefs.SetFloat("MusicControl" , VolSlider.value);
    }
    
}
