using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Respawn : MonoBehaviour
{
    private Hungry playerHunger;
    private Transform current;
    private UIManager uiManager; 
    private float damage;

    private void Awake()
    {
        playerHunger = GetComponent<Hungry>(); // get hungry component 
        uiManager = FindObjectOfType<UIManager>(); // get ui component
    }

    public void Restart() // restart func.
    {
        uiManager.GameOver(); // game over displayed
        transform.position = current.position; // move player to ori place
        playerHunger.TakeDamage(damage); // restore hunger
    }
}