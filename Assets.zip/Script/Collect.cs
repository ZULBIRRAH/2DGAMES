using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Collect : MonoBehaviour
{
    public static Collect instance;
 

    private int coins = 0;
    private int infos = 0; 

    [SerializeField] private TextMeshProUGUI coinsText;
    [SerializeField] private TextMeshProUGUI infosText;
    [SerializeField] private GameObject PopUpBox;
    Collider2D collision;

    [SerializeField] private AudioSource coinSound;
    [SerializeField] private AudioSource infoSound;


    public void Awake()
    {
        PopUpBox.SetActive(false);
        instance = this;
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("coin"))
        {
            
            coins++;
            coinsText.text= coins.ToString();
            coinSound.Play();
            Destroy(collision.gameObject);
        }

        if (collision.gameObject.CompareTag("info"))
        {
            
            infos++;
            infosText.text= infos.ToString();
            PopUpBox.SetActive(true);   
            infoSound.Play();
            Destroy(collision.gameObject);  
        }
    }

    public void AddFood(float increase)
    {
            coins-=1;
            coinsText.text= coins.ToString();
    }

    public void level(int pass)
    {
        if (infos == 2)
        {
           nextlevel.instance.next();
        }
        else if (infos == 0 || infos == 1)
        {
            nextlevel.instance.Awake();
        }
    }


}
